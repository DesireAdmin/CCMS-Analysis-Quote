﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace MyApp.ServiceModel.DatabaseModel
{
    public class QuoteModel
    {
        [Key]
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [Required(ErrorMessage = "SMG Vendor PO is required.")]
        [RegularExpression(@"^\d{6}(-\d{2})?$", ErrorMessage = "SMG Vendor PO must be in the format ###### or ######-##.")]
        public string SMG_Vendor_PO { get; set; }

        public DateTime Date { get; set; }

        [Required(ErrorMessage = "Client name is required.")]
        public string SMG_CLIENT { get; set; }
        public string StoreNumber { get; set; }

        [Required(ErrorMessage = "Location is required.")]
        public string Location { get; set; }

        //[Required(ErrorMessage = "City and State are required.")]
        //public string CityState { get; set; }

        [Required(ErrorMessage = "Vendor is required.")]
        public string Vendor { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid email format.")]
        public string Email { get; set; }
        public string ServiceRepName { get; set; }

        public bool IsIncurredCost { get; set; }

        public List<ProposedBreakout> ProposedBreakouts { get; set; } = new List<ProposedBreakout>();
        public List<IncurredBreakout> IncurredBreakouts { get; set; } = new List<IncurredBreakout>();

        public IncurredTotal IncurredTotals { get; set; } = new IncurredTotal();
        public ProposedTotal ProposedTotals { get; set; } = new ProposedTotal();
        public string AttachmentUrl { get; set; }
        [NotMapped]
        public  IFormFile AttachmentFile { get; set; }

        [Required(ErrorMessage = "Message is required.")]
        public string Message { get; set; }

        [Required(ErrorMessage = "Disclaimer is required.")]
        public string Disclaimer { get; set; }

        [Required(ErrorMessage = "Description of Services is required.")]
        public string DescriptionOfServices { get; set; }

        [Required(ErrorMessage = "Signature Name of Services is required.")]
        public string SignatureName { get; set; } = "Arun";

        [Required(ErrorMessage = "Checked of Services is required.")]
        public bool IsChecked { get; set; }= true;
    }
}
